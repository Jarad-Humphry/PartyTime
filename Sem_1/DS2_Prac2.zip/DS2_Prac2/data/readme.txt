The word list in this directory is courtesy of Stanford University.
http://www-cs-faculty.stanford.edu/~uno/sgb.html
