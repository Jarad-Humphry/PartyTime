//package test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Test;
import graph.*;
import java.io.*;
import java.util.ArrayList;


//import Doublets.class;



public class TestDoublets
	{
	@Test
	public void TestSolve()
		throws FileNotFoundException, IOException {
		Doublets d = new Doublets("data/sgb-words.txt");
		ArrayList <String> AL = new ArrayList <String>();
		AL.add("would");
		AL.add("could");
		assertEquals(AL, d.solve("would", "could"));
		}

	@Test 
	public void TestSolve2()
		throws FileNotFoundException, IOException {
		Doublets d = new Doublets("data/sgb-words2.txt");
		ArrayList <String> AL = new ArrayList <String>();
		AL.add("lead");
		AL.add("load");
		AL.add("goad");
		AL.add("gold");
		assertEquals(AL, d.solve("lead", "gold"));
		}
	}
