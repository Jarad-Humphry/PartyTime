import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Test;
import graph.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

public class TestGraph
	{
	AdjacencyMapGraph<String, String> AMG;
	Vertex <String> v1, v2, v3, v4, v5, v6, v7;
	Edge <String> e1, e2, e3, e4;

	//@Before
	public void setup()
		{
		AMG = new AdjacencyMapGraph<String, String>();
		v1 = AMG.insert("vert1");
		v2 = AMG.insert("vert2");
		v3 = AMG.insert("vert3");
		v4 = AMG.insert("vert4");
		v5 = AMG.insert("vert5");
		v6 = AMG.insert("vert5");
		}

	/*@Test
	public void testgetIncidentOn()
		{
		setup();
		e1 = AMG.insert(v1, v2, "");
		//Set<AdjacencyMapEdge<E, V>> edges;
		//edges = AMG.getEdges().iterator();
		/while (edges.hasNext())
			{
			if (edges.next() == e1)
				{
				
				}
			}/
		
		assertEquals(e1, AMG.getIncidentOn(v1).iterator().next());  
		}*/

	@Test
	public void testGetVertices()
		{
		setup();
		e1 = AMG.insert(v1, v2, "");
		Pair p1 = new Pair(v1, v2);
		//AMG.getVertices(e1);
		assertEquals(p1, AMG.getVertices(e1));
		//end();
		}

	@Test
	public void testgetOpposite()
		{
		setup();
		e1 = AMG.insert(v1, v2, "");
		assertEquals(v2, AMG.getOpposite(v1, e1));
		assertEquals(v1, AMG.getOpposite(v2, e1));
		//end();
		}

	@Test
	public void testareAdjacent()
		{
		setup();
		e1 = AMG.insert(v1, v2, "");
		e2 = AMG.insert(v1, v3, "");
		assertEquals(true, AMG.areAdjacent(v1, v2));
		assertEquals(true, AMG.areAdjacent(v2, v1));
		assertEquals(true, AMG.areAdjacent(v1, v3));
		assertEquals(false, AMG.areAdjacent(v1, v4));
		end();
		}

	@Test
	public void testreplace()
		{
		setup();
		e1 = AMG.insert(v1, v2, "");
		AMG.replace(v1, "yes");
		assertEquals(v1.getValue(), "yes");
		AMG.replace(e1, "yes");
		assertEquals(e1.getValue(), "yes");
		end();
		}

	@Test
	public void testremove1()
		{
		setup();
		e1 = AMG.insert(v1, v2, "ya");
		e2 = AMG.insert(v1, v2, "");
		assertEquals("vert1", AMG.remove(v1));
		end();
		}
		
	@Test
	public void testremove2()
		{
		setup();
		e1 = AMG.insert(v1, v2, "ya");
		e2 = AMG.insert(v1, v2, "");
		e3 = AMG.insert(v2, v3, "");
		assertEquals("ya", AMG.remove(e1));
		end();
		}

	@Test
	public void testmark()
		{
		setup();
		v1.mark();
		e1 = AMG.insert(v1, v2, "ya");
		AMG.clearMarks();
		end();
		}

	//@After
	public void end()
		{
		AMG.dump();
		}

		





	}
