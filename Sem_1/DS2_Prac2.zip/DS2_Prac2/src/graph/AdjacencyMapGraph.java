package graph;
import java.util.HashSet;
import java.util.Set;
import java.util.Iterator;
/**
 *
 * An implementation of Graph that uses a linked representation 
 * (vertex and edge objects). 
 * <p>
 * It is called 'AdjacencyMapGraph' because each vertex stores an adjacency 
 * Map of edges incident upon it (as opposed to an adjacency list).
 *<p>
 * Operations such as inserting or deleting an edge involve updating the
 * adjacency maps of the vertices incident upon it.
 *  
 * @author Stephan Jamieson
 * @version 1/4/2016
 */
 public class AdjacencyMapGraph<V, E> implements Graph<V, E> {
	 
	private Set<AdjacencyMapVertex<V, E>> vertices;
	private Set<AdjacencyMapEdge<E, V>> edges;
	
	/**
	 * Create a new graph.
	 */
	public AdjacencyMapGraph() {
		this.vertices = new HashSet<AdjacencyMapVertex<V, E>>();
		this.edges = new HashSet<AdjacencyMapEdge<E, V>>();
	}
	
	public Iterable<AdjacencyMapVertex<V, E>> getVertices() { return vertices; }

	public Iterable<AdjacencyMapEdge<E, V>> getEdges() { return edges; }
   
	public Iterable<AdjacencyMapEdge<E, V>> getIncidentOn(final Vertex<V> vertex) {
		// Your code here
		AdjacencyMapVertex<V, E> AMV = cast(vertex);
		return AMV.getIncidentOn();
		
	}

	public Iterable<AdjacencyMapVertex<V, E>> getNeighbours(Vertex<V> v) {
		// Your code here
		AdjacencyMapVertex<V, E> AMV = cast(v);
		return AMV.getNeighbours();
	
	}
		
	public Pair<AdjacencyMapVertex<V, E>> getVertices(final Edge<E> edge) {
		// Your code here
		AdjacencyMapEdge<E, V> AME = cast(edge);
		return AME.getVertices();
		
	}
    
	public AdjacencyMapVertex<V, E> getOpposite(final Vertex<V> vertex, final Edge<E> edge){
		// Your code here
		AdjacencyMapVertex<V, E> AMV = cast(vertex);
		AdjacencyMapEdge<E, V> AME = cast(edge);
		return AME.getOpposite(AMV);

	}
    
	public boolean areAdjacent(final Vertex<V> v, final Vertex<V> w) {
		// Your code here
		AdjacencyMapVertex<V, E> AMV1 = cast(v);
		AdjacencyMapVertex<V, E> AMV2 = cast(w);
		if (AMV1.isAdjacentTo(AMV2))
			{
			return true;
			}

		/*else if (AMV2.isAdjacentTo(AMV1))
			{
			return true;
			}*/
		else 
			{
			return false;
			}
			
	}
   
	public V replace(final Vertex<V> vertex, final V value) {
		// Your code here
		
		vertex.setValue(value);
		return value;
	}

	public E replace(final Edge<E> edge, final E value) {
		// Your code here
		//AdjacencyMapEdge<E, V> AME = cast(edge);
		//Pair pr = new Pair(AME.getVertices());
		//pr = ;
		//AME.replace(AME.getVertices().getLeft(), AME.getVertices().getRight());
		edge.setValue(value);
		return value;
	}
   
	public AdjacencyMapVertex<V, E> insert(final V value) {
		// Your code here
		AdjacencyMapVertex<V, E> AMV = createVertex(value);
		//AMV.setOwner(this);
		/*if (vertices.contains(AMV))
			{
			return AMV;
			}*/
		Iterator<AdjacencyMapVertex<V, E>> iterAMV = getVertices().iterator();
		while (iterAMV.hasNext())
			{
			if (iterAMV.next() == AMV)
				{
				return iterAMV.next();
				}
			//iterAMV.next();
			}
		vertices.add(AMV);
		return AMV;
	}

	public AdjacencyMapEdge<E, V> insert(Vertex<V> v, Vertex<V> w, E value) throws IllegalArgumentException {
		// Your code here
		AdjacencyMapVertex<V, E> AMV1 = cast(v);
		AdjacencyMapVertex<V, E> AMV2 = cast(w);
		AdjacencyMapEdge<E, V> AME = createEdge(AMV1, AMV2, value);
		Iterator<AdjacencyMapEdge<E, V>> iterAME = getEdges().iterator();
		while (iterAME.hasNext())
			{
			if (iterAME.next() == AME)
				{
				throw new IllegalArgumentException("an edge exists between v and w");
				}
			//iterAME.next();
			}


		
		AMV1.insert(AME);
		AMV2.insert(AME);
		//AME.setOwner(this);
		//AdjacencyMapEdge<E, V> AME = new AdjacencyMapEdge<E, V>(AMV1, AMV2, value);
		edges.add(AME);

		return AME;
	}
   
	public V remove(Vertex<V> vertex) {
		// Your code here
		//vertices.remove(vertex);
		AdjacencyMapVertex<V, E> AMV = cast(vertex);
		

		Iterator<AdjacencyMapEdge<E, V>> iter1 = getIncidentOn(vertex).iterator();	
		while (iter1.hasNext())
			{
			edges.remove(iter1.next());
			}

		Iterator<AdjacencyMapVertex<V, E>> iter2 = getNeighbours(vertex).iterator();
		while (iter2.hasNext())
			{
			iter2.next().remove(AMV);
			}


		vertices.remove(vertex);
		return vertex.getValue();
		}

	public E remove(Edge<E> edge)  {
		// Your code here
		Pair<AdjacencyMapVertex<V, E>> p = cast(edge).getVertices();
		p.getLeft().remove(cast(edge));
		p.getRight().remove(cast(edge));
		edges.remove(edge);
		return edge.getValue();
	}
	
	public void clearMarks() {
		// Your code here
		Iterator<AdjacencyMapVertex<V, E>> iterAMV = getVertices().iterator();
		Iterator<AdjacencyMapEdge<E, V>> iterAME = getEdges().iterator();
		while (iterAME.hasNext())
			{
			iterAME.next().clearMark();
			}
		while (iterAMV.hasNext())
			{
			iterAMV.next().clearMark();
			}
	}		
	/*
	 * The following methods should be used to create edges and vertices.
	 * They ensure that the objects created are marked as belonging to
	 * this graph object.
	 */
	 
	 
	private AdjacencyMapVertex<V, E> createVertex(final V value) {
		final AdjacencyMapVertex<V, E> vertex = new AdjacencyMapVertex<V, E>(value);
		vertex.setOwner(this);
		return vertex;
	}

	private AdjacencyMapEdge<E, V> createEdge(final AdjacencyMapVertex<V,E> v, 
		final AdjacencyMapVertex<V, E> w, final E value) {
			final AdjacencyMapEdge<E, V> edge = new AdjacencyMapEdge<E, V>(v, w, value);
			edge.setOwner(this);
			return edge;
	}

	/*
	 * The Graph<V, E> interface uses Edge<E> and Vertex<V> data types.
	 * Internally, an AdjacencyMapGraph<V, E> uses AdjacencyMapVertex<V, E>
	 * and AdjacencyMapEdge<E, V> data types. The following methods
	 * may be used to safely cast from one to the other.
	 */
	 
	@SuppressWarnings("unchecked")
	private AdjacencyMapEdge<E, V> cast(final Edge<E> edge) {
		assert(edge.belongsTo(this));
		return (AdjacencyMapEdge<E, V>)edge;		
	}

	/**
	 *
	 */
	@SuppressWarnings("unchecked")	
	private AdjacencyMapVertex<V, E> cast(final Vertex<V> vertex) {
		assert(vertex.belongsTo(this));
		return (AdjacencyMapVertex<V, E>)vertex;
	}
	
	/**
	 * Obtain a dump (for debugging purposes) of the graph representation.
	 */ 
	public void dump() {
		dumpVertices();
		dumpEdges();
		System.out.println();
	} 
	
	/**
	 * Obtain a dump (for debugging purposes) of the vertex representations.
	 */ 
	public void dumpVertices() {
		System.out.print("\nVERTICES");
		for (AdjacencyMapVertex<V, E> vertex : vertices) {
			vertex.dump();
		}
	}
	
	/**
	 * Obtain a dump (for debugging purposes) of the edge representations.
	 */ 
	public void dumpEdges() {
		System.out.print("\nEDGES");
		for (AdjacencyMapEdge<E, V> edge : edges) {
			System.out.print("\n"+edge);
		}
	}	
	
 }
