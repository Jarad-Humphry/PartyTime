import java.io.*;
//
//import graph.Vertex;
//import graph.Graph;
import graph.*;


//
import utils.ClusterBuilder;
//
import java.io.FileNotFoundException;
//

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
/**
 *
 * Solver for Lewis Carrol's Doublets game.
 *
 */
 public class Doublets {
 
	private Map<String, Vertex<String>> wordList;
	private Graph<String, String> graph;
	
	/**
	 * Create a Doublets object for solving problems over the words in the given file.
	 * @throws FileNotFoundException
	 */
	public Doublets(final String wordFile) throws FileNotFoundException, IOException {
		// Your code here.
		this.wordList = new HashMap<String, Vertex<String>>();
		this.graph = new AdjacencyMapGraph<String, String>();
		//graph.dump();
		HashMap <String, String> newhm = new HashMap <String, String>();
		File f1 = new File(wordFile);
		FileReader fr = new FileReader(f1);
		ClusterBuilder cb = new ClusterBuilder(fr);
		
		while (cb.hasNext())
			{	
			ArrayList<String> listt = new ArrayList<String>();
			listt.addAll(cb.next());
			for (String i : listt)
				{
				//
				if (this.wordList.containsKey(i))
					{
					
					}
				else 
					{
					this.wordList.put(i, graph.insert(i));
					}

				for (String k : listt)
					{
					if ((i != k) && (wordList.containsKey(k)))
						{
						if ((newhm.containsKey(i)) || (newhm.containsKey(k)))
							{
							
							}
						else
							{
							newhm.put(i, k);
							newhm.put(k, i);
							
								graph.insert(wordList.get(i), wordList.get(k), "");
							}
						}
					
					}
				}
			newhm.clear();		
			}
	
		
	}

		

	/**
	 * Obtain the solution to the doublet (wordOne, wordTwo).
	 * Returns null if one or other of the words is not in the lexicon.
	 * Returns an empty list if there is no solution.
	 * Otherwise returns a list of words beginning with wordOne and ending 
	 * in wordTwo, with zero or more intervening words. 
	 * <p>
	 * The list is such that (i) any adjacent pair of words in the list differ
	 * by at most one letter, and (ii) it represents the shortest route from
	 * wordOne to wordTwo.
	 */

	public List<String> solve(final String wordOne, final String wordTwo) 
		{ 
		List <Vertex<String>> lis = shortestPath(wordList.get(wordOne), wordList.get(wordTwo));
		ArrayList <String> ls = new ArrayList<String>();

		for (Vertex<String> vs : lis)
			{
			ls.add(vs.getValue());
			}
		return ls;
		//return lis;
		}
		
		//method written by Stephan Jamieson
		public List<Vertex<String>> shortestPath(final Vertex<String> vOne, final Vertex<String> vTwo) {
			
			// Set up
		final List<List<Vertex<String>>> paths = new ArrayList<List<Vertex<String>>>();
		final List<Vertex<String>> initialPath = new ArrayList<Vertex<String>>();
		vOne.mark();
		initialPath.add(vOne);	paths.add(initialPath);
			
		List<Vertex<String>> path;
		while (true) {
			path = paths.remove(0);
			final Vertex<String> end = path.get(path.size()-1);
			if (end==vTwo) {
				break;
			}
			else {
				for(Vertex<String> neighbour : graph.getNeighbours(end)) {
					final List<Vertex<String>> newPath = new ArrayList<Vertex<String>>(path);
					if (!neighbour.isMarked()) {
						neighbour.mark();
						newPath.add(neighbour);
						paths.add(newPath);
					}
				}
			}
		}
		graph.clearMarks();
		if (path.size()==1) {
			return null;
		}
		else {
			return path;
		}
	}	
	// Your code here.
 }
