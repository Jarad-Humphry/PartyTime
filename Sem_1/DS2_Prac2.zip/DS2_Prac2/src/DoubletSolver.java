import java.util.*;
import java.io.FileNotFoundException;
import java.io.*;

public class DoubletSolver
	{
	public static void main(String[] args) throws FileNotFoundException, IOException{

		Scanner in = new Scanner(System.in);
		Doublets doub = new Doublets("../data/sgb-words.txt");
		System.out.println("Enter a doublet (two words separated by a comma), or 'quit'");
		ArrayList <String> AL = new ArrayList <String>();
      		String s = in.nextLine();
		String s1;
		String s2;
		char aChar;
		int i = 0;
		String [] sa;
		//ArrayList <String> ls = new ArrayList<String>();
		while (!s.equals("quit"))
			{
			s = s.toLowerCase();
			sa = s.split(", ");
			s1=sa[0];
			s2=sa[1];
			//System.out.println(s1 + " and " + s2);
			if ((s1.length()!=5) || (s2.length())!=5)
				{
				System.out.println("Sorry, words must be 5 letters.");
				}
			else
				{
				List<String> ls = doub.solve(s1, s2);
				if (ls == null)
					{
					System.out.println("Sorry, insufficient data.");
					}
				else
					{
					for (String h : ls)
						{
						System.out.println(h.toUpperCase());
						}
					}
				}
			s = in.nextLine();	
			}
		}
	}
